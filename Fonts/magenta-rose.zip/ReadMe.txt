This font is partial and FREE PERSONAL USE ONLY
NO COMMERCIAL USE ALLOWED!

Be Careful and take the time to read any terms & conditions before deciding to use the font commercially.
Ignorance is not an excuse for breaking the law.

By installing or using this font, you are hereby agree to this Font Usage Agreement:
1. This font is ONLY FOR PERSONAL USE purposes
2. NO PROMOTIONAL & COMMERCIAL USE ALLOWED
3. You are REQUIRES A LICENSE for Promotional or Commercial Use

You can support us by buying the license here:
https://s.id/MagentaRoseFont

Please visit our store for more premium fonts : 
https://fontbundles.net/diqtam/rel=Auh8HP

Check our premium font bundles
https://pixelsurplus.com/?ref=drmwn

You can send your donation through our Paypal account:
https://www.paypal.me/diqtam

or simply click the Donate Button at the download page

Thanks, You are AWESOME